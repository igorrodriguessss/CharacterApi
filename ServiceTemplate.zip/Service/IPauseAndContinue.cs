namespace $safeprojectname$.Service
{
    interface IPauseAndContinue
    {
        void Pause();
        void Continue();
    }
}